<?php 

function traduz_prioridade($codigo){
	$prioridade = '';

	switch ($codigo) {
		case 1:
			$prioridade = 'Baixa';
			break;
		case 2:
			$prioridade = 'Media';
			break;
		case 3:
			$prioridade = 'Alta';
			break;
	}
	return $prioridade;
}

?>