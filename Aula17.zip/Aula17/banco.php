<?php 

$bdServidor = '127.0.0.1';
$bdUsuario = 'sistematarefas';
$bdSenha = 'sistema';
$bdBanco = 'tarefas';

$conexao = mysqli_connect($bdServidor, $bdUsuario, $bdSenha, $bdBanco);

if ($conexao) {
	//echo "Conexão autorizada!";
	
}
else{
	echo "</br>";
	echo "Error connecting to database! Check if the configuration is correct! </br>";
	echo "Server / User / Password / Database";
	die();
}

function buscar_tarefas($conexao){
	$sqlBusca = 'SELECT * FROM tarefas';
	$resultado = mysqli_query($conexao, $sqlBusca);

	$tarefas = [];

	while ($tarefa = mysqli_fetch_assoc($resultado)){

		$tarefas[] = $tarefa;
	}
	//print_r($tarefas);

	return $tarefas;
}

function gravar_tarefa($conexao, $tarefa){
	$sqlGravar = "
		INSERT INTO tarefas 
		(nome, descricao, prioridade)
		VALUES
		(
			'{$tarefa['nome']}',
			'{$tarefa['descricao']}',
			{$tarefa['prioridade']}
		)
	";

	mysqli_query($conexao, $sqlGravar);
}
?>