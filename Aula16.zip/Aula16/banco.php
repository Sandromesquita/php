<?php 

$bdServidor = '127.0.0.1';
$bdUsuario = 'sistematarefas';
$bdSenha = 'sistema';
$bdBanco = 'tarefas';

$conexao = mysqli_connect($bdServidor, $bdUsuario, $bdSenha, $bdBanco);

if ($conexao) {
	//echo "Conexão autorizada!";
	
}
else{
	echo "</br>";
	echo "Error connecting to database! Check if the configuration is correct! </br>";
	echo "Server / User / Password / Database";
	die();
}


?>